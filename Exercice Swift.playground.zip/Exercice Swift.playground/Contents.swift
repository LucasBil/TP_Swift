import UIKit

// Excercice 1
//Générez un nouveau tableau d’une taille de 20 entiers aléatoires de type Int.
//Créez une fonction qui prend en paramètre ce tableau d’entiers et qui retourne la somme de tous les éléments du tableau.
//Retournez la moyenne de tous les éléments du tableau.
//Retournez la valeur maximale du tableau.
//Filtrez les éléments pairs du tableau et retournez le tableau.
//Transformez le tableau en un tableau de String et retournez le tableau.

var array = [Int]()
for _ in 1...20 {
    array.append(Int.random(in: 1...100))
}

func sum(variable array: [Int]) -> Int{
    var res : Int = 0
    array.forEach { value in
        res += value
    }
    return res
}

func avg(array: [Int]) -> Double{
    if array.count == 0 {
        return 0
    }
    return Double(sum(variable: array)/array.count)
}

func max(array : [Int]) -> Int? {
    let res = array.max()
    if let res {
        return res
    }
    else{
        return nil
    }
}

func even(array : [Int]) -> [Int] {
    return array.filter({ value in
        return value%2 == 0
    })
}

func arrayToString(array : [Int]) -> [String] {
    var res = [String]()
    array.forEach({value in
        res.append(String(value))
    })
    return res
}

print(array)
print(sum(variable: array))
print(avg(array: array))
print(max(array: array))
print(even(array: array))
print(arrayToString(array: array))

// Exercice 2
//Créer une fonction dans l’énum permettant d’afficher un émoji correspondant à l’animal.
//Créer une fonction qui retourne 🥩 pour les animaux carnivores, 🥕 pour les animaux herbivores et 🍔 pour les animaux omnivores.
//Créer une fonction qui retourne le nom de l’animal en Français.
//Créer une fonction qui retourne la phrase suivante en fonction de l’animal : “{animal (en 🇫🇷)}{:son emoji} est {type d’alimentation}{🥩/🥕/🍔}” vous n’utiliserez pas de switch ou de if pour cet exercice.

enum Animal: CaseIterable {
    case cat
    case dog
    case elephant
    case giraffe
    case panda
    case penguin
    case cheetah
    case dolphin
    case lion
    case turtle
    
    func toEmoji() -> String {
        switch(self){
            case Animal.cat :
                return "🐱"
            case Animal.dog :
                return "🐶"
            case Animal.elephant :
                return "🐘"
            case Animal.giraffe :
                return "🦒"
            case Animal.panda :
                return "🐼"
            case Animal.penguin :
                return "🐧"
            case Animal.cheetah :
                return "🐆"
            case Animal.dolphin :
                return "🐬"
            case Animal.lion :
                return "🦁"
            case Animal.turtle :
                return "🐢"
        }
    }
    
    func eat() -> String {
        switch(self){
            case Animal.cat, Animal.lion, Animal.cheetah, Animal.dog :
                return "🥩"
            case Animal.giraffe, Animal.elephant, Animal.turtle, Animal.panda :
                return "🥕"
            case Animal.penguin, Animal.dolphin :
                return "🍔"
        }
    }
    
    func name() -> String {
        switch(self){
            case Animal.cat :
                return "chat"
            case Animal.dog :
                return "chien"
            case Animal.elephant :
                return "elephant"
            case Animal.giraffe :
                return "giraffe"
            case Animal.panda :
                return "panda"
            case Animal.penguin :
                return "penguin"
            case Animal.cheetah :
                return "guepard"
            case Animal.dolphin :
                return "dauphin"
            case Animal.lion :
                return "lion"
            case Animal.turtle :
                return "tortue"
        }
    }
    
    func sentence() -> String{
        return "\(self.name()) \(self.toEmoji()) est \(self.eat())"
    }
}

var animalSentences = ""
Animal.allCases.forEach({ animal in
    animalSentences += "\(animal.sentence())\n"
})
print(animalSentences)

// Execice 3
//Filtrer les personnes qui ont un age nil.
//Filtrer les personnes qui ont une ville nil.
//Filtrer les personnes qui ont un age nil et une ville nil.
//Afficher “Majeur” si la personne a plus de 18 ans, “Mineur” sinon, si l’age est nil, afficher “Age inconnu”.

struct Person {
    var name: String
    var age: Int?
    var city: String?
}

let people: [Person] = [
    Person(name: "Alice", age: 25, city: "Paris-sur-Mer"),
    Person(name: "Bob", age: nil, city: "Croissant-ville"),
    Person(name: "Charlie", age: 30, city: "Baguette-ville"),
    Person(name: "David", age: nil, city: "Escargot-terre"),
    Person(name: "Eva", age: 22, city: "Fromage-sur-Ciel"),
    Person(name: "Frank", age: 40, city: "Tour-Eiffel-land"),
    Person(name: "Grace", age: 18, city: "Chapeau-Rouge")
]

